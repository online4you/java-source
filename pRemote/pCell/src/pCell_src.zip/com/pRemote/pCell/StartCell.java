package com.pRemote.pCell;
/* 
 * Copyright 2012 - www.puigros.es 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not 
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at 
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0 
 *   
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the 
 * License for the specific language governing permissions and limitations 
 * under the License.
 * 
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

import org.apache.log4j.Logger;
import org.quartz.SchedulerException;

import com.pRemote.commonServices.util.AppModelProperties;
import com.pRemote.interfaces.messages.IMessage;
import com.pRemote.messages.Message;

/**
 * Clase con el m�todo main para arrancar la c�lula.
 * Puede recibir el par�metro -l para arrancarcala autom�mticamente 
 *
 * @author Guillem
 * @version	1.0 25/10/2012
 */
 

public class StartCell {
	
	public static void main(String[] args) throws IOException, SchedulerException, InterruptedException {
		AppModelProperties prop=new AppModelProperties();
		Cell cell=new Cell();
		Logger log=Logger.getLogger("Main");
		String dateFormat=prop.getProperty("com.pRemote.messageDateFormat");
		char getChar;
		String getStr;
		
		if (args.length>0){
			for (String arg: args) {
		        if(arg.equals("-l")){
		        	cell.listen();
		        	cell.shutdown();
		        	log.info("Bye!!!");
		        }
		    }
		}else{
			try {
				
					while (true){
						getChar=1;
						System.out.println("L-Listen");
						System.out.println("S-to-message Send Message");
						System.out.println("\tExample: S-127.0.0.1:5224-0001_0001_0001##0000_0000_0000##ONOFF_ON_AUTO##20/09/2012 23:00:00:000##20/09/2012 23:30:00:000: S-[message]Send Message");
						System.out.println("\t[device_node_systemFrom##device_node_systemTo##messageType_Operation##time##validUntill]");
						System.out.println("E-Exit");
				        		
						BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
						getStr = bufferRead.readLine();
					    System.out.println("\n\nLets proccess: " + getStr);
					    
					    					
						
			       		if (!getStr.equals("")){
				       		if (getStr.toLowerCase().compareTo("l")==0){
				       			cell.listen();
				       			break;
				       		}else if (getStr.substring(0,1).toLowerCase().compareTo("s")==0){
				       			IMessage msg=new Message(getStr.split("-")[2],dateFormat);
				       			System.out.println(cell.sendMessageToCell(msg, getStr.split("-")[1].split(":")[0], Integer.parseInt(getStr.split("-")[1].split(":")[1])));
				       		}else if (getStr.toLowerCase().compareTo("e")==0){
				       			break;
				       		}
						}
			       		
					}
					cell.shutdown();
					log.info("Bye!!!");;
			} catch (Exception e) { 
				log.error(e.getMessage(),e);
			
			}
		}
		
	}

}
